package com.ali.chatgpt;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.gson.JsonObject;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private com.ali.chatgpt.MessageAdapter messageAdapter;
    private ArrayList<Message> messages;
    private EditText inputMessage;
    private ImageButton sendButton;

    private final String API_KEY = "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"; // Replace with your API key

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        inputMessage = findViewById(R.id.inputMessage);
        sendButton = findViewById(R.id.sendButton);

        messages = new ArrayList<>();
        messageAdapter = new com.ali.chatgpt.MessageAdapter(messages);
        recyclerView.setAdapter(messageAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userMessage = inputMessage.getText().toString().trim();
                if (!userMessage.isEmpty()) {
                    addMessage(userMessage, true);
                    callAPI(userMessage);
                    inputMessage.setText("");
                }
            }
        });
    }

    private void addMessage(String text, boolean isUser) {
        messages.add(new Message(text, isUser));
        messageAdapter.notifyDataSetChanged();
        recyclerView.smoothScrollToPosition(messages.size() - 1);
    }

    private void callAPI(String userMessage) {
        OkHttpClient client = new OkHttpClient();

        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("model", "text-davinci-003");
            jsonObject.put("prompt", userMessage);
            jsonObject.put("max_tokens", 150);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        RequestBody body = RequestBody.create(
                jsonObject.toString(),
                MediaType.parse("application/json")
        );

        Request request = new Request.Builder()
                .url("https://api.openai.com/v1/completions")
                .header("Authorization", "Bearer " + API_KEY)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
                runOnUiThread(() -> addMessage("Error: " + e.getMessage(), false));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    try {
                        JSONObject jsonResponse = new JSONObject(response.body().string());
                        String botReply = jsonResponse.getJSONArray("choices").getJSONObject(0).getString("text").trim();
                        runOnUiThread(() -> addMessage(botReply, false));
                    } catch (JSONException e) {
                        e.printStackTrace();
                        runOnUiThread(() -> addMessage("Error parsing response", false));
                    }
                } else {
                    runOnUiThread(() -> addMessage("Error: " + response.message(), false));
                }
            }
        });
    }
}
